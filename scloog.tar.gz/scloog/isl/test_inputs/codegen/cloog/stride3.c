for (int c0 = max(m, 1); c0 <= n; c0 += 1)
  S1(c0);
