{
  for (int c2 = 0; c2 <= n; c2 += 1)
    S1(c2, 0, 0);
  for (int c2 = 0; c2 <= n; c2 += 1)
    S2(0, c2, 0);
}
