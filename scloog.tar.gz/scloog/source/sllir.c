/*
 * sllir.c
 *
 *  Created on: Jun 29, 2015
 *      Author: danieles
 */

#include <assert.h>

#include "../include/cloog/sllir.h"

static void free_sll_stmt(struct sll_expr *ss)
{
    struct sll_stmt *ps = (struct sll_stmt *)ss;
    assert(SLL_EXPR_IS_A(ss, sll_et_stmt));
    struct sll_expr *next;
    struct sll_expr *s = ps->body;
    while (s) {
    	next = s->next;
    	free_sll_expr(s);
    	s = next;
    }
    sdsfree(ss->out);
    sdsfree(ss->scat);
    free(ps);
}

const struct sll_etype sll_et_stmt = { free_sll_stmt };

struct sll_stmt *new_sll_stmt(struct sll_expr *context)
{
    struct sll_stmt *s = malloc(sizeof(struct sll_stmt));
    s->expr.et = &sll_et_stmt;
    s->expr.next = NULL;
    s->expr.context = context;
    s->expr.out  = NULL;
    s->expr.scat = NULL;
    s->expr.eq_id = -1;
    s->body = NULL;
    return s;
}

static void free_sll_entry(struct sll_expr *se)
{
    struct sll_entry *ps = (struct sll_entry *)se;
    assert(SLL_EXPR_IS_A(se, sll_et_entry));
    sdsfree(se->out);
    sdsfree(se->scat);
    free(ps);
}

const struct sll_etype sll_et_entry = { free_sll_entry };

struct sll_entry *new_sll_entry(struct sll_expr *context)
{
    struct sll_entry *s = malloc(sizeof(struct sll_entry));
    s->expr.et = &sll_et_entry;
    s->expr.next = NULL;
    s->expr.context = context;
    s->expr.out  = NULL;
    s->expr.scat = NULL;
    s->expr.eq_id = -1;
    s->len = 0;
    return s;
}

static void free_sll_inner_expr(struct sll_expr *sie)
{
    struct sll_inner_expr *ps = (struct sll_inner_expr *)sie;
    assert(SLL_EXPR_IS_A(sie, sll_et_inner));
    sdsfree(ps->text);
    sdsfree(sie->out);
    sdsfree(sie->scat);
    free(ps);
}

const struct sll_etype sll_et_inner = { free_sll_inner_expr };

struct sll_inner_expr *new_sll_inner_expr(struct sll_expr *context)
{
    struct sll_inner_expr *s = malloc(sizeof(struct sll_inner_expr));
    s->expr.et = &sll_et_inner;
    s->expr.next = NULL;
    s->expr.context = context;
    s->expr.out  = NULL;
    s->expr.scat = NULL;
    s->expr.eq_id = -1;
    s->text = sdsnew("");
    return s;
}

static void free_sll_block(struct sll_expr *sb)
{
    struct sll_block *ps = (struct sll_block *)sb;
    assert(SLL_EXPR_IS_A(sb, sll_et_block));
    struct sll_expr *next;
    struct sll_expr *s = ps->body;
    while (s) {
    	next = s->next;
    	free_sll_expr(s);
    	s = next;
    }
    sdsfree(sb->out);
    sdsfree(sb->scat);
    free(ps);
}

const struct sll_etype sll_et_block = { free_sll_block };

struct sll_block *new_sll_block(struct sll_expr *context)
{
    struct sll_block *s = malloc(sizeof(struct sll_block));
    s->expr.et = &sll_et_block;
    s->expr.next = NULL;
    s->expr.context = context;
    s->expr.out  = NULL;
    s->expr.scat = NULL;
    s->expr.eq_id = -1;
    s->body = NULL;
    return s;
}

static void free_sll_for(struct sll_expr *sf)
{
    struct sll_for *ps = (struct sll_for *)sf;
    assert(SLL_EXPR_IS_A(sf, sll_et_for));
    struct sll_expr *next;
    struct sll_expr *s = ps->body;
    while (s) {
    	next = s->next;
    	free_sll_expr(s);
    	s = next;
    }
    sdsfree(ps->iterator);
    sdsfree(ps->lb);
    sdsfree(ps->ub);
    sdsfree(ps->stride);
    sdsfree(sf->out);
    sdsfree(sf->scat);
    free(ps);
}

const struct sll_etype sll_et_for = { free_sll_for };

struct sll_for *new_sll_for(struct sll_expr *context)
{
    struct sll_for *s = malloc(sizeof(struct sll_for));
    s->expr.et = &sll_et_for;
    s->expr.next = NULL;
    s->expr.context = context;
    s->expr.out  = NULL;
    s->expr.scat = NULL;
    s->expr.eq_id = -1;
    s->body = NULL;
    s->iterator = sdsnew("");
    s->lb = sdsnew("");
    s->ub = sdsnew("");
    s->stride = sdsnew("");
    return s;
}

static void free_sll_guard(struct sll_expr *sg)
{
    struct sll_guard *ps = (struct sll_guard *)sg;
    assert(SLL_EXPR_IS_A(sg, sll_et_guard));
    struct sll_expr *next;
    struct sll_expr *s = ps->then;
    while (s) {
    	next = s->next;
    	free_sll_expr(s);
    	s = next;
    }
    sdsfree(ps->cond);
    sdsfree(sg->out);
    sdsfree(sg->scat);
    free(ps);
}

const struct sll_etype sll_et_guard = { free_sll_guard };

struct sll_guard *new_sll_guard(struct sll_expr *context)
{
    struct sll_guard *s = malloc(sizeof(struct sll_guard));
    s->expr.et = &sll_et_guard;
    s->expr.next = NULL;
    s->expr.context = context;
    s->expr.out  = NULL;
    s->expr.scat = NULL;
    s->expr.eq_id = -1;
    s->then = NULL;
    s->cond = sdsnew("");
    return s;
}

void free_sll_expr(struct sll_expr *s)
{
    assert(s->et);
    assert(s->et->free);
    s->et->free(s);
}

void sll_free(struct sll_expr *s)
{
    struct sll_expr *next;
    while (s) {
    	next = s->next;
    	free_sll_expr(s);
    	s = next;
    }
}

struct sll_expr *build_from_expr_list(struct sll_expr *context, struct sll_expr *se);

void build_from_guard(struct sll_guard *sg)
{
	sg->then = build_from_expr_list(&(sg->expr), sg->then);
	if(sg->then->next == NULL) {
		struct sll_stmt *bstmt = (struct sll_stmt *)sg->then;
		sg->expr.out = sdsdup(bstmt->body->out);
		sg->expr.eq_id = bstmt->body->eq_id;
	} else {
		sg->expr.out = sdsnew("#");
	}
}

void build_from_for(struct sll_for *sf)
{
	sf->body = build_from_expr_list(&(sf->expr), sf->body);
	if((sf->body->next == NULL) && (sf->iterator[0] != 'f')) {
		struct sll_stmt *bstmt = (struct sll_stmt *)sf->body;
		sf->expr.out = sdsdup(bstmt->body->out);
		sf->expr.eq_id = bstmt->body->eq_id;
	} else {
		sf->expr.out = sdsnew("#");
	}
}


struct sll_expr *build_from_expr_list(struct sll_expr *context, struct sll_expr *se)
{
	int i;
	struct sll_stmt *head_stmt = new_sll_stmt(context);
	struct sll_stmt *curr_stmt = head_stmt;

	struct sll_entry *old_entry = (struct sll_entry*)se;
	struct sll_expr *curr_expr = se->next; //, *tmp_expr = NULL;

	struct sll_entry *new_entry = new_sll_entry(context);
	struct sll_expr *curr_new_expr = &(new_entry->expr);

	sds hash = sdsnew("#");

	for (i = 0; i < old_entry->len; ++i) {
		if (SLL_EXPR_IS_A(curr_expr, sll_et_for)) {
			build_from_for((struct sll_for *)(curr_expr));
		} else if (SLL_EXPR_IS_A(curr_expr, sll_et_guard)) {
			build_from_guard((struct sll_guard *)(curr_expr));
		}

		if ((new_entry->expr.out != NULL)
				&& ((sdscmp(curr_expr->out, hash) == 0)
						|| (sdscmp(new_entry->expr.out, curr_expr->out) != 0) || (new_entry->expr.eq_id != curr_expr->eq_id)) )
		{
			curr_new_expr->next = NULL;
			curr_stmt->body = &(new_entry->expr);
			struct sll_stmt *new_stmt = new_sll_stmt(context);
			curr_stmt->expr.next = &(new_stmt->expr);
			curr_stmt = new_stmt;
			new_entry = new_sll_entry(context);
			curr_new_expr = &(new_entry->expr);
		}
//		if ((new_entry->expr.out == NULL) || (sdscmp(new_entry->expr.out, curr_expr->out) == 0)) {
		curr_new_expr->next = curr_expr;
		curr_new_expr = curr_expr;
		curr_expr = curr_expr->next;
		new_entry->len++;
		new_entry->expr.out  = sdsdup(curr_new_expr->out);
		new_entry->expr.eq_id  = curr_new_expr->eq_id;
//		} else {
//			curr_new_expr->next = NULL;
//			curr_stmt->body = &(new_entry->expr);
//			struct sll_stmt *new_stmt = new_sll_stmt(context);
//			curr_stmt->expr.next = &(new_stmt->expr);
//			curr_stmt = new_stmt;
//			new_entry = new_sll_entry(context);
//			new_entry->expr.next = curr_expr;
//			curr_new_expr = curr_expr;
//			new_entry->len++;
//			new_entry->expr.out  = sdsdup(curr_new_expr->out);
//			curr_expr = curr_expr->next;
//		}
	}

	if(!(SLL_EXPR_IS_A(curr_new_expr, sll_et_entry)))
	{
		curr_stmt->body = &(new_entry->expr);
	}

	old_entry->expr.next = NULL;
	free_sll_entry(se);
	sdsfree(hash);

	return &(head_stmt->expr);
}

struct sll_expr *build_sll_program(struct sll_expr *s)
{
	return build_from_expr_list(s->context, s);
}
