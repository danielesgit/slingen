
   /**-------------------------------------------------------------------**
    **                              CLooG                                **
    **-------------------------------------------------------------------**
    **                             pprint.c                              **
    **-------------------------------------------------------------------**
    **                  First version: october 26th 2001                 **
    **-------------------------------------------------------------------**/


/******************************************************************************
 *               CLooG : the Chunky Loop Generator (experimental)             *
 ******************************************************************************
 *                                                                            *
 * Copyright (C) 2001-2005 Cedric Bastoul                                     *
 *                                                                            *
 * This library is free software; you can redistribute it and/or              *
 * modify it under the terms of the GNU Lesser General Public                 *
 * License as published by the Free Software Foundation; either               *
 * version 2.1 of the License, or (at your option) any later version.         *
 *                                                                            *
 * This library is distributed in the hope that it will be useful,            *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          *
 * Lesser General Public License for more details.                            *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public           *
 * License along with this library; if not, write to the Free Software        *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor,                         *
 * Boston, MA  02110-1301  USA                                                *
 *                                                                            *
 * CLooG, the Chunky Loop Generator                                           *
 * Written by Cedric Bastoul, Cedric.Bastoul@inria.fr                         *
 *                                                                            *
 ******************************************************************************/
/* CAUTION: the english used for comments is probably the worst you ever read,
 *          please feel free to correct and improve it !
 */

/* June    22nd 2005: General adaptation for GMP.
 * October 26th 2005: General adaptation from CloogDomain to Matrix data
 *                    structure for all constraint systems.
 * October 27th 2005: General adaptation from CloogEqual to Matrix data
 *                    structure for equality spreading.
 */

# include <stdlib.h>
# include <stdio.h>
# include <string.h>
#include <assert.h>
# include "../include/cloog/cloog.h"
#include "sds.c"
#include "sllir.c"

#ifdef OSL_SUPPORT
#include <osl/util.h>
#include <osl/macros.h>
#include <osl/int.h>
#include <osl/body.h>
#include <osl/extensions/extbody.h>
#include <osl/statement.h>
#include <osl/scop.h>
#endif


static void pprint_name(FILE *dst, struct clast_name *n);
static void pprint_term(struct cloogoptions *i, FILE *dst, struct clast_term *t);
static void pprint_sum(struct cloogoptions *opt,
			FILE *dst, struct clast_reduction *r);
static void pprint_binary(struct cloogoptions *i,
			FILE *dst, struct clast_binary *b);
static void pprint_minmax_f(struct cloogoptions *info,
			FILE *dst, struct clast_reduction *r);
static void pprint_minmax_c(struct cloogoptions *info,
			FILE *dst, struct clast_reduction *r);
static void pprint_reduction(struct cloogoptions *i,
			FILE *dst, struct clast_reduction *r);
static void pprint_expr(struct cloogoptions *i, FILE *dst, struct clast_expr *e);
static void pprint_equation(struct cloogoptions *i,
			FILE *dst, struct clast_equation *eq);
static void pprint_assignment(struct cloogoptions *i, FILE *dst, 
			struct clast_assignment *a);
static void pprint_user_stmt(struct cloogoptions *options, FILE *dst,
		       struct clast_user_stmt *u);
static void pprint_guard(struct cloogoptions *options, FILE *dst, int indent,
		   struct clast_guard *g);
static void pprint_for(struct cloogoptions *options, FILE *dst, int indent,
		 struct clast_for *f);
static void pprint_stmt_list(struct cloogoptions *options, FILE *dst, int indent,
		       struct clast_stmt *s);

static sds sds_pprint_name(sds s, struct clast_name *n);
static sds sds_pprint_term(struct cloogoptions *i, sds s, struct clast_term *t);
static sds sds_pprint_sum(struct cloogoptions *opt, sds s, struct clast_reduction *r);
static sds sds_pprint_binary(struct cloogoptions *i, sds s, struct clast_binary *b);
static sds sds_pprint_minmax_c(struct cloogoptions *info, sds s, struct clast_reduction *r);
static sds sds_pprint_reduction(struct cloogoptions *i, sds s, struct clast_reduction *r);
static sds sds_pprint_expr(struct cloogoptions *i, sds s, struct clast_expr *e);
static sds sds_pprint_assignment(struct cloogoptions *i, sds s, struct clast_assignment *a);
static sds sds_pprint_equation(struct cloogoptions *i, sds dst, struct clast_equation *eq);
static sds sds_pprint_guard(struct cloogoptions *options, sds dst, int indent, struct clast_guard *g);
static sds sds_pprint_for(struct cloogoptions *options, sds dst, int indent, struct clast_for *f);
static sds sds_pprint_stmt_list(struct cloogoptions *options, sds dst, int indent, struct clast_stmt *s);

static struct sll_expr * sll_clast_stmt_list(struct sll_expr * context, struct cloogoptions *options, struct clast_stmt *s);
static sds sds_sll_expr_list(sds dst, int indent, struct sll_expr *s);
static sds sds_sll_stmt(sds dst, int indent, struct sll_stmt *ss);

void pprint_name(FILE *dst, struct clast_name *n)
{
    fprintf(dst, "%s", n->name);
}

sds sds_pprint_name(sds s, struct clast_name *n)
{
    s = sdscatprintf(s, "%s", n->name);
    return s;
}

/**
 * This function returns a string containing the printing of a value (possibly
 * an iterator or a parameter with its coefficient or a constant).
 * - val is the coefficient or constant value,
 * - name is a string containing the name of the iterator or of the parameter,
 */
void pprint_term(struct cloogoptions *i, FILE *dst, struct clast_term *t)
{
    if (t->var) {
	int group = t->var->type == clast_expr_red &&
		    ((struct clast_reduction*) t->var)->n > 1;
	if (cloog_int_is_one(t->val))
	    ;
	else if (cloog_int_is_neg_one(t->val))
	    fprintf(dst, "-");
        else {
	    cloog_int_print(dst, t->val);
	    fprintf(dst, "*");
	}
	if (group)
	    fprintf(dst, "(");
	pprint_expr(i, dst, t->var);
	if (group)
	    fprintf(dst, ")");
    } else
	cloog_int_print(dst, t->val);
}

sds sds_pprint_term(struct cloogoptions *i, sds s, struct clast_term *t)
{
    if (t->var) {
	    int group = t->var->type == clast_expr_red && ((struct clast_reduction*) t->var)->n > 1;
	    if (cloog_int_is_one(t->val))
	      ;
	    else if (cloog_int_is_neg_one(t->val)) {
	      s = sdscatprintf(s, "-");
      } else {
	      sds_cloog_int_print(s, t->val);
	      //s = sdscatprintf(s, "%d", t->val);
	      s = sdscatprintf(s, "*");
	    }
	    
	    if (group)
	      s = sdscatprintf(s, "(");
    	s = sds_pprint_expr(i, s, t->var);
	    if (group)
	      s = sdscatprintf(s, ")");
    } else
	      //s = sdscatprintf(s, "%d", t->val);
    	sds_cloog_int_print(s, t->val);
	
	  return s;
}

void pprint_sum(struct cloogoptions *opt, FILE *dst, struct clast_reduction *r)
{
    int i;
    struct clast_term *t;

    assert(r->n >= 1);
    assert(r->elts[0]->type == clast_expr_term);
    t = (struct clast_term *) r->elts[0];
    pprint_term(opt, dst, t);

    for (i = 1; i < r->n; ++i) {
	assert(r->elts[i]->type == clast_expr_term);
	t = (struct clast_term *) r->elts[i];
	if (cloog_int_is_pos(t->val))
	    fprintf(dst, "+");
	pprint_term(opt, dst, t);
    }
}

sds sds_pprint_sum(struct cloogoptions *opt, sds s, struct clast_reduction *r)
{
    int i;
    struct clast_term *t;

    assert(r->n >= 1);
    assert(r->elts[0]->type == clast_expr_term);
    t = (struct clast_term *) r->elts[0];
    s = sds_pprint_term(opt, s, t);

    for (i = 1; i < r->n; ++i) {
	    assert(r->elts[i]->type == clast_expr_term);
	    t = (struct clast_term *) r->elts[i];
    	if (cloog_int_is_pos(t->val))
	      s = sdscatprintf(s, "+");
    	s = sds_pprint_term(opt, s, t);
    }
    
    return s;
}

void pprint_binary(struct cloogoptions *i, FILE *dst, struct clast_binary *b)
{
    const char *s1 = NULL, *s2 = NULL, *s3 = NULL;
    int group = b->LHS->type == clast_expr_red &&
		((struct clast_reduction*) b->LHS)->n > 1;
    if (i->language == CLOOG_LANGUAGE_FORTRAN) {
	switch (b->type) {
	case clast_bin_fdiv:
	    s1 = "FLOOR(REAL(", s2 = ")/REAL(", s3 = "))";
	    break;
	case clast_bin_cdiv:
	    s1 = "CEILING(REAL(", s2 = ")/REAL(", s3 = "))";
	    break;
	case clast_bin_div:
	    if (group)
		s1 = "(", s2 = ")/", s3 = "";
	    else
		s1 = "", s2 = "/", s3 = "";
	    break;
	case clast_bin_mod:
	    s1 = "MOD(", s2 = ", ", s3 = ")";
	    break;
	}
    } else {
	switch (b->type) {
	case clast_bin_fdiv:
	    s1 = "floord(", s2 = ",", s3 = ")";
	    break;
	case clast_bin_cdiv:
	    s1 = "ceild(", s2 = ",", s3 = ")";
	    break;
	case clast_bin_div:
	    if (group)
		s1 = "(", s2 = ")/", s3 = "";
	    else
		s1 = "", s2 = "/", s3 = "";
	    break;
	case clast_bin_mod:
	    if (group)
		s1 = "(", s2 = ")%", s3 = "";
	    else
		s1 = "", s2 = "%", s3 = "";
	    break;
	}
    }
    fprintf(dst, "%s", s1);
    pprint_expr(i, dst, b->LHS);
    fprintf(dst, "%s", s2);
    cloog_int_print(dst, b->RHS);
    fprintf(dst, "%s", s3);
}

sds sds_pprint_binary(struct cloogoptions *i, sds s, struct clast_binary *b)
{
    const char *s1 = NULL, *s2 = NULL, *s3 = NULL;
    int group = b->LHS->type == clast_expr_red && ((struct clast_reduction*) b->LHS)->n > 1;
  	switch (b->type) {
      	case clast_bin_fdiv:
	        s1 = "floord(", s2 = ",", s3 = ")";
	        break;
      	case clast_bin_cdiv:
	        s1 = "ceild(", s2 = ",", s3 = ")";
	        break;
      	case clast_bin_div:
    	    if (group)
        		s1 = "(", s2 = ")/", s3 = "";
    	    else
        		s1 = "", s2 = "/", s3 = "";
    	    break;
      	case clast_bin_mod:
    	    if (group)
        		s1 = "(", s2 = ")%", s3 = "";
    	    else
        		s1 = "", s2 = "%", s3 = "";
    	    break;
    }
    s = sdscatprintf(s, "%s", s1);
    s = sds_pprint_expr(i, s, b->LHS);
    s = sdscatprintf(s, "%s", s2);
    sds_cloog_int_print(s, b->RHS);
    //s = sdscatprintf(s, "%d", b->RHS);
    s = sdscatprintf(s, "%s", s3);
    return s;
}

void pprint_minmax_f(struct cloogoptions *info, FILE *dst, struct clast_reduction *r)
{
    int i;
    if (r->n == 0)
	return;
    fprintf(dst, r->type == clast_red_max ? "MAX(" : "MIN(");
    pprint_expr(info, dst, r->elts[0]);
    for (i = 1; i < r->n; ++i) {
	fprintf(dst, ",");
	pprint_expr(info, dst, r->elts[i]);
    }
    fprintf(dst, ")");
}

void pprint_minmax_c(struct cloogoptions *info, FILE *dst, struct clast_reduction *r)
{
    int i;
    for (i = 1; i < r->n; ++i)
	fprintf(dst, r->type == clast_red_max ? "max(" : "min(");
    if (r->n > 0)
	pprint_expr(info, dst, r->elts[0]);
    for (i = 1; i < r->n; ++i) {
	fprintf(dst, ",");
	pprint_expr(info, dst, r->elts[i]);
	fprintf(dst, ")");
    }
}

sds sds_pprint_minmax_c(struct cloogoptions *info, sds s, struct clast_reduction *r)
{
    int i;
    for (i = 1; i < r->n; ++i)
    	s = sdscatprintf(s, r->type == clast_red_max ? "max(" : "min(");
    if (r->n > 0)
    	s = sds_pprint_expr(info, s, r->elts[0]);
    for (i = 1; i < r->n; ++i) {
    	s = sdscatprintf(s, ",");
	    s = sds_pprint_expr(info, s, r->elts[i]);
    	s = sdscatprintf(s, ")");
    }
    return s;
}

void pprint_reduction(struct cloogoptions *i, FILE *dst, struct clast_reduction *r)
{
    switch (r->type) {
    case clast_red_sum:
	pprint_sum(i, dst, r);
	break;
    case clast_red_min:
    case clast_red_max:
	if (r->n == 1) {
	    pprint_expr(i, dst, r->elts[0]);
	    break;
	}
	if (i->language == CLOOG_LANGUAGE_FORTRAN)
	    pprint_minmax_f(i, dst, r);
	else
	    pprint_minmax_c(i, dst, r);
	break;
    default:
	assert(0);
    }
}

sds sds_pprint_reduction(struct cloogoptions *i, sds s, struct clast_reduction *r)
{
    switch (r->type) {
      case clast_red_sum:
      	s = sds_pprint_sum(i, s, r);
      	break;
      case clast_red_min:
      case clast_red_max:
	      if (r->n == 1) {
    	    s = sds_pprint_expr(i, s, r->elts[0]);
	        break;
      	}
        s = sds_pprint_minmax_c(i, s, r);
      	break;
      default:
      	assert(0);
    }
    
    return s;
}

void pprint_expr(struct cloogoptions *i, FILE *dst, struct clast_expr *e)
{
    if (!e)
	return;
    switch (e->type) {
    case clast_expr_name:
	pprint_name(dst, (struct clast_name*) e);
	break;
    case clast_expr_term:
	pprint_term(i, dst, (struct clast_term*) e);
	break;
    case clast_expr_red:
	pprint_reduction(i, dst, (struct clast_reduction*) e);
	break;
    case clast_expr_bin:
	pprint_binary(i, dst, (struct clast_binary*) e);
	break;
    default:
	assert(0);
    }
}

sds sds_pprint_expr(struct cloogoptions *i, sds s, struct clast_expr *e)
{
    if (!e) return s;
    switch (e->type) {
      case clast_expr_name:
      	s = sds_pprint_name(s, (struct clast_name*) e);
      	break;
      case clast_expr_term:
	      s = sds_pprint_term(i, s, (struct clast_term*) e);
	      break;
      case clast_expr_red:
	      s = sds_pprint_reduction(i, s, (struct clast_reduction*) e);
	      break;
      case clast_expr_bin:
	      s = sds_pprint_binary(i, s, (struct clast_binary*) e);
	      break;
      default:
	      assert(0);
    }
    
    return s;
}

void pprint_equation(struct cloogoptions *i, FILE *dst, struct clast_equation *eq)
{
    pprint_expr(i, dst, eq->LHS);
    if (eq->sign == 0)
	fprintf(dst, " == ");
    else if (eq->sign > 0)
	fprintf(dst, " >= ");
    else
	fprintf(dst, " <= ");
    pprint_expr(i, dst, eq->RHS);
}

sds sds_pprint_equation(struct cloogoptions *i, sds dst, struct clast_equation *eq)
{
    dst = sds_pprint_expr(i, dst, eq->LHS);
    if (eq->sign == 0)
    	dst = sdscatprintf(dst, " == ");
    else if (eq->sign > 0)
    	dst = sdscatprintf(dst, " >= ");
    else
    	dst = sdscatprintf(dst, " <= ");
    dst = sds_pprint_expr(i, dst, eq->RHS);
    return dst;
}

void pprint_assignment(struct cloogoptions *i, FILE *dst, 
			struct clast_assignment *a)
{
    if (a->LHS)
	fprintf(dst, "%s = ", a->LHS);
    pprint_expr(i, dst, a->RHS);
}

sds sds_pprint_assignment(struct cloogoptions *i, sds s, 
			struct clast_assignment *a)
{
    if (a->LHS)
	    s = sdscatprintf(s, "%s = ", a->LHS);
    s = sds_pprint_expr(i, s, a->RHS);
    
    return s;
}

/**
 * pprint_osl_body function:
 * this function pretty-prints the OpenScop body of a given statement.
 * It returns 1 if it succeeds to find an OpenScop body to print for
 * that statement, 0 otherwise.
 * \param[in] options CLooG Options.
 * \param[in] dst     Output stream.
 * \param[in] u       Statement to print the OpenScop body.
 * \return 1 on success to pretty-print an OpenScop body for u, 0 otherwise.
 */
int pprint_osl_body(struct cloogoptions *options, FILE *dst,
                    struct clast_user_stmt *u) {
#ifdef OSL_SUPPORT
  int i;
  char *expr, *tmp;
  struct clast_stmt *t;
  osl_scop_p scop = options->scop;
  osl_statement_p stmt;
  osl_body_p body;

  if ((scop != NULL) &&
      (osl_statement_number(scop->statement) >= u->statement->number)) {
    stmt = scop->statement;

    /* Go to the convenient statement in the SCoP. */
    for (i = 1; i < u->statement->number; i++)
      stmt = stmt->next;

    /* Ensure it has a printable body. */
    body = NULL;
    if (osl_generic_has_URI(stmt->body, OSL_URI_BODY)) {
      body = stmt->body->data;
    } else if (osl_generic_has_URI(stmt->body, OSL_URI_EXTBODY)) {
      if (stmt->body->data != NULL) {
        body = ((osl_extbody_p)(stmt->body->data))->body;
      }
    }
    if ((body != NULL) &&
        (body->expression != NULL) &&
        (body->iterators != NULL)) {
      expr = osl_util_identifier_substitution(body->expression->string[0],
                                              body->iterators->string);
      tmp = expr;
      /* Print the body expression, substituting the @...@ markers. */
      while (*expr) {
        if (*expr == '@') {
          int iterator;
          expr += sscanf(expr, "@%d", &iterator) + 2; /* 2 for the @s */
          t = u->substitutions;
          for (i = 0; i < iterator; i++)
            t = t->next;
          pprint_assignment(options, dst, (struct clast_assignment *)t);
        } else {
          fprintf(dst, "%c", *expr++);
        }
      }
      fprintf(dst, "\n");
      free(tmp);
      return 1;
    }
  }
#endif
  return 0;
}

sds *sds_pprint_osl_body(struct cloogoptions *options,
                    struct clast_user_stmt *u, char readout) {
	sds *res = NULL;
#ifdef OSL_SUPPORT
	int i, n = 1;
	char *expr, *tmp;
	struct clast_stmt *t;
	osl_scop_p scop = options->scop;
	osl_statement_p stmt;
	osl_body_p body;

	if ((scop != NULL) &&
			(osl_statement_number(scop->statement) >= u->statement->number)) {
		stmt = scop->statement;

		/* Go to the convenient statement in the SCoP. */
		for (i = 1; i < u->statement->number; i++)
			stmt = stmt->next;

		/* Ensure it has a printable body. */
		body = NULL;
		if (osl_generic_has_URI(stmt->body, OSL_URI_BODY)) {
			body = stmt->body->data;
		} else if (osl_generic_has_URI(stmt->body, OSL_URI_EXTBODY)) {
			if (stmt->body->data != NULL) {
				body = ((osl_extbody_p)(stmt->body->data))->body;
			}
		}

		if ((body != NULL) && (body->iterators != NULL)) {
			if (readout) n=4;
			res = (sds *)malloc(n*sizeof(sds *));

			for(i=0; i<n; ++i)
				res[i] = sdsempty();

			if (body->expression != NULL) {
				expr = osl_util_identifier_substitution(body->expression->string[0],
						body->iterators->string);
				tmp = expr;
				/* Print the body expression, substituting the @...@ markers. */
				while (*expr) {
					if (*expr == '@') {
						int iterator, read;
						//          expr += sscanf(expr, "@%d", &iterator) + 2; /* 2 for the @s */
						read = sscanf(expr, "@%d", &iterator);
						if(!read) {
							cloog_die("Couldn't read between @...@ markers.\n");
						} else {
							expr += 2 + (int)sdslen(sdsfromlonglong(iterator)); /* 2 for the @s */
						}
						t = u->substitutions;
						for (i = 0; i < iterator; i++)
							t = t->next;
						res[0] = sdscatprintf(res[0], "(");
						res[0] = sds_pprint_assignment(options, res[0], (struct clast_assignment *)t);
						res[0] = sdscatprintf(res[0], ")");
					} else {
						res[0] = sdscatprintf(res[0], "%c", *expr++);
					}
				}
				res[0] = sdscatprintf(res[0], "\n");
				free(tmp);
			}

			if (n>1) {

				if (body->out != NULL) {
					res[1] = sdscatprintf(res[1], "%s", body->out->string[0]);
				}

				if (body->scat != NULL) {
					expr = osl_util_identifier_substitution(body->scat->string[0],
							body->iterators->string);
					tmp = expr;
					/* Print the body expression, substituting the @...@ markers. */
					while (*expr) {
						if (*expr == '@') {
							int iterator, read;
							//          expr += sscanf(expr, "@%d", &iterator) + 2; /* 2 for the @s */
							read = sscanf(expr, "@%d", &iterator);
							if(!read) {
								cloog_die("Couldn't read between @...@ markers in scat.\n");
							} else {
								expr += 2 + (int)sdslen(sdsfromlonglong(iterator)); /* 2 for the @s */
							}
							t = u->substitutions;
							for (i = 0; i < iterator; i++)
								t = t->next;
							res[2] = sdscatprintf(res[2], "(");
							res[2] = sds_pprint_assignment(options, res[2], (struct clast_assignment *)t);
							res[2] = sdscatprintf(res[2], ")");
						} else {
							res[2] = sdscatprintf(res[2], "%c", *expr++);
						}
					}
					res[2] = sdscatprintf(res[2], "\n");
					free(tmp);
				}

				res[3] = sdscatprintf(res[3], "%d", osl_int_get_si(OSL_PRECISION_SP, body->eq_id));

			}
		}
	}
#endif
	return res;
}

void pprint_user_stmt(struct cloogoptions *options, FILE *dst,
		       struct clast_user_stmt *u)
{
    struct clast_stmt *t;

    if (pprint_osl_body(options, dst, u))
      return;
    
    if (u->statement->name)
	fprintf(dst, "%s", u->statement->name);
    else
	fprintf(dst, "S%d", u->statement->number);
    fprintf(dst, "(");
    for (t = u->substitutions; t; t = t->next) {
	assert(CLAST_STMT_IS_A(t, stmt_ass));
	pprint_assignment(options, dst, (struct clast_assignment *)t);
	if (t->next)
	    fprintf(dst, ",");
    }
    fprintf(dst, ")");
    if (options->language != CLOOG_LANGUAGE_FORTRAN)
	fprintf(dst, ";");
    fprintf(dst, "\n");
}

sds sds_pprint_user_stmt(struct cloogoptions *options, sds dst,
		       struct clast_user_stmt *u)
{
    sds * b = sds_pprint_osl_body(options, u, 0);
    if (b != NULL) {
    	dst = sdscatprintf(dst, "%s", *b);
    	free(b);
    }
    return dst;
}

struct sll_expr * sll_clast_user_stmt(struct sll_expr * context, struct cloogoptions *options, struct clast_user_stmt *u)
{
	struct sll_inner_expr * sie = new_sll_inner_expr(context);
    sds * b = sds_pprint_osl_body(options, u, 1);
    if (b != NULL) {
    	sie->text = b[0];
    	sie->expr.out  = b[1];
    	sie->expr.scat = b[2];
    	sie->expr.eq_id = atoi(b[3]);
    	free(b);
    }
    return &(sie->expr);

}

sds sds_sll_inner_expr(sds dst, struct sll_inner_expr *s)
{
	return sdscatprintf(dst, "%s", s->text);
}


void pprint_guard(struct cloogoptions *options, FILE *dst, int indent,
		   struct clast_guard *g)
{
    int k;
    if (options->language == CLOOG_LANGUAGE_FORTRAN)
	fprintf(dst,"IF ");
    else
	fprintf(dst,"if ");
    if (g->n > 1)
	fprintf(dst,"(");
    for (k = 0; k < g->n; ++k) {
	if (k > 0) {
	    if (options->language == CLOOG_LANGUAGE_FORTRAN)
		fprintf(dst," .AND. ");
	    else
		fprintf(dst," && ");
	}
	fprintf(dst,"(");
        pprint_equation(options, dst, &g->eq[k]);
	fprintf(dst,")");
    }
    if (g->n > 1)
	fprintf(dst,")");
    if (options->language == CLOOG_LANGUAGE_FORTRAN)
	fprintf(dst," THEN\n");
    else
	fprintf(dst," {\n");

    pprint_stmt_list(options, dst, indent + INDENT_STEP, g->then);

    fprintf(dst, "%*s", indent, "");
    if (options->language == CLOOG_LANGUAGE_FORTRAN)
	fprintf(dst,"END IF\n"); 
    else
	fprintf(dst,"}\n"); 
}

sds sds_pprint_guard(struct cloogoptions *options, sds dst, int indent,
		   struct clast_guard *g)
{
    int k;
    if (options->language == CLOOG_LANGUAGE_FORTRAN)
    	dst = sdscatprintf(dst,"IF ");
    else if (options->language == CLOOG_LANGUAGE_SIGMA)
    	dst = sdscatprintf(dst,"(\n");
    else
    	dst = sdscatprintf(dst,"if ");

    if (options->language != CLOOG_LANGUAGE_SIGMA) {
      if (g->n > 1)
	      dst = sdscatprintf(dst,"(");
      for (k = 0; k < g->n; ++k) {
	      if (k > 0) {
	          if (options->language == CLOOG_LANGUAGE_FORTRAN)
		          dst = sdscatprintf(dst," .AND. ");
	          else
      		    dst = sdscatprintf(dst," && ");
	      }
	      dst = sdscatprintf(dst,"(");
        dst = sds_pprint_equation(options, dst, &g->eq[k]);
	      dst = sdscatprintf(dst,")");
      }
      if (g->n > 1)
	      dst = sdscatprintf(dst,")");
      if (options->language == CLOOG_LANGUAGE_FORTRAN)
      	dst = sdscatprintf(dst," THEN\n");
      else
      	dst = sdscatprintf(dst," {\n");
    }

    dst = sds_pprint_stmt_list(options, dst, indent + INDENT_STEP, g->then);

    if (options->language == CLOOG_LANGUAGE_SIGMA) {
        dst = sdscatprintf(dst, "%*s", indent, "");
      	dst = sdscatprintf(dst,")[");
        for (k = 0; k < g->n; ++k) {
	        if (k > 0) {
    		    dst = sdscatprintf(dst," && ");
	        }
	        dst = sdscatprintf(dst,"(");
          dst = sds_pprint_equation(options, dst, &g->eq[k]);
	        dst = sdscatprintf(dst,")");
        }
      	dst = sdscatprintf(dst,"]\n");
    } else {
      dst = sdscatprintf(dst, "%*s", indent, "");
      if (options->language == CLOOG_LANGUAGE_FORTRAN)
	      dst = sdscatprintf(dst,"END IF\n"); 
      else
      	dst = sdscatprintf(dst,"}\n");
    }
    return dst;
}

struct sll_expr * sll_clast_guard(struct sll_expr * context, struct cloogoptions *options, struct clast_guard *g)
{
    int k;
    struct sll_guard * sg = new_sll_guard(context);

    sg->then = sll_clast_stmt_list(&(sg->expr), options, g->then);

    for (k = 0; k < g->n; ++k) {
    	if (k > 0) {
    		sg->cond = sdscatprintf(sg->cond, " && ");
    	}
    	sg->cond = sdscatprintf(sg->cond, "(");
    	sg->cond = sds_pprint_equation(options, sg->cond, &g->eq[k]);
    	sg->cond = sdscatprintf(sg->cond, ")");
    }

    return &(sg->expr);

}

sds sds_sll_guard(sds dst, int indent, struct sll_guard *sg)
{

	sds hash = sdsnew("#");
	int pasif = (sdscmp(sg->expr.out, hash) == 0);

	if (pasif)
	    dst = sdscatprintf(dst,"If [ %s ] {\n", sg->cond);
	else
		dst = sdscatprintf(dst,"(\n");

    dst = sds_sll_stmt(dst, indent + INDENT_STEP, (struct sll_stmt *)(sg->then));

    dst = sdscatprintf(dst, "%*s", indent, "");
    if (pasif)
		dst = sdscatprintf(dst, "}\n");
    else
    	dst = sdscatprintf(dst,")[ %s ]\n", sg->cond);

    sdsfree(hash);

    return dst;
}

void pprint_for(struct cloogoptions *options, FILE *dst, int indent,
		 struct clast_for *f)
{
    if (options->language == CLOOG_LANGUAGE_C) {
        if ((f->parallel & CLAST_PARALLEL_OMP) && !(f->parallel & CLAST_PARALLEL_MPI)) {
            if (f->LB) {
                fprintf(dst, "lbp=");
                pprint_expr(options, dst, f->LB);
                fprintf(dst, ";\n");
            }
            if (f->UB) {
                fprintf(dst, "%*s", indent, "");
                fprintf(dst, "ubp=");
                pprint_expr(options, dst, f->UB);
                fprintf(dst, ";\n");
            }
            fprintf(dst, "#pragma omp parallel for%s%s%s%s%s%s\n",
                    (f->private_vars)? " private(":"",
                    (f->private_vars)? f->private_vars: "",
                    (f->private_vars)? ")":"",
                    (f->reduction_vars)? " reduction(": "",
                    (f->reduction_vars)? f->reduction_vars: "",
                    (f->reduction_vars)? ")": "");
            fprintf(dst, "%*s", indent, "");
        }
        if ((f->parallel & CLAST_PARALLEL_VEC) && !(f->parallel & CLAST_PARALLEL_OMP)
               && !(f->parallel & CLAST_PARALLEL_MPI)) {
            if (f->LB) {
                fprintf(dst, "lbv=");
                pprint_expr(options, dst, f->LB);
                fprintf(dst, ";\n");
            }
            if (f->UB) {
                fprintf(dst, "%*s", indent, "");
                fprintf(dst, "ubv=");
                pprint_expr(options, dst, f->UB);
                fprintf(dst, ";\n");
            }
            fprintf(dst, "%*s#pragma ivdep\n", indent, "");
            fprintf(dst, "%*s#pragma vector always\n", indent, "");
            fprintf(dst, "%*s", indent, "");
        }
        if (f->parallel & CLAST_PARALLEL_MPI) {
            if (f->LB) {
                fprintf(dst, "_lb_dist=");
                pprint_expr(options, dst, f->LB);
                fprintf(dst, ";\n");
            }
            if (f->UB) {
                fprintf(dst, "%*s", indent, "");
                fprintf(dst, "_ub_dist=");
                pprint_expr(options, dst, f->UB);
                fprintf(dst, ";\n");
            }
            fprintf(dst, "%*s", indent, "");
            fprintf(dst, "polyrt_loop_dist(_lb_dist, _ub_dist, nprocs, my_rank, &lbp, &ubp);\n");
            if (f->parallel & CLAST_PARALLEL_OMP) {
                fprintf(dst, "#pragma omp parallel for%s%s%s%s%s%s\n",
                        (f->private_vars)? " private(":"",
                        (f->private_vars)? f->private_vars: "",
                        (f->private_vars)? ")":"",
                        (f->reduction_vars)? " reduction(": "",
                        (f->reduction_vars)? f->reduction_vars: "",
                        (f->reduction_vars)? ")": "");
            }
            fprintf(dst, "%*s", indent, "");
        }

    }

    if (options->language == CLOOG_LANGUAGE_FORTRAN)
	fprintf(dst, "DO ");
    else if (options->language == CLOOG_LANGUAGE_SIGMA)
	fprintf(dst, "Sum [ ");
    else
	fprintf(dst, "for (");

    if (f->LB) {
      if (options->language == CLOOG_LANGUAGE_SIGMA)
        fprintf(dst, "%s;", f->iterator);
      else fprintf(dst, "%s=", f->iterator);
        if (f->parallel & (CLAST_PARALLEL_OMP | CLAST_PARALLEL_MPI)) {
            fprintf(dst, "lbp");
        }else if (f->parallel & CLAST_PARALLEL_VEC){
            fprintf(dst, "lbv");
        }else{
	pprint_expr(options, dst, f->LB);
        }
    } else if (options->language == CLOOG_LANGUAGE_FORTRAN)
	cloog_die("unbounded loops not allowed in FORTRAN.\n");

    if (options->language == CLOOG_LANGUAGE_FORTRAN)
	fprintf(dst,", ");
    else
	fprintf(dst,";");

    if (f->UB) {
	    if (options->language != CLOOG_LANGUAGE_FORTRAN && options->language != CLOOG_LANGUAGE_SIGMA )
	        fprintf(dst,"%s<=", f->iterator);
      
        if (f->parallel & (CLAST_PARALLEL_OMP | CLAST_PARALLEL_MPI)) {
            fprintf(dst, "ubp");
        }else if (f->parallel & CLAST_PARALLEL_VEC){
            fprintf(dst, "ubv");
        }else{
            pprint_expr(options, dst, f->UB);
        }
      if (options->language == CLOOG_LANGUAGE_SIGMA)
        fprintf(dst, ";");
        
    }else if (options->language == CLOOG_LANGUAGE_FORTRAN)
	cloog_die("unbounded loops not allowed in FORTRAN.\n");

    if (options->language == CLOOG_LANGUAGE_FORTRAN) {
	if (cloog_int_gt_si(f->stride, 1))
	    cloog_int_print(dst, f->stride);
	fprintf(dst,"\n");
    } else if (options->language == CLOOG_LANGUAGE_SIGMA) {
//	    fprintf(dst, ";%s=%s+", f->iterator, f->iterator);
	    cloog_int_print(dst, f->stride);
	    fprintf(dst, " ] {\n");
   } else {
	if (cloog_int_gt_si(f->stride, 1)) {
	    fprintf(dst,";%s+=", f->iterator);
	    cloog_int_print(dst, f->stride);
	    fprintf(dst, ") {\n");
      } else
	fprintf(dst, ";%s++) {\n", f->iterator);
    }

    pprint_stmt_list(options, dst, indent + INDENT_STEP, f->body);

    fprintf(dst, "%*s", indent, "");
    if (options->language == CLOOG_LANGUAGE_FORTRAN)
	fprintf(dst,"END DO\n") ; 
    else
	fprintf(dst,"}\n") ; 
}

sds sds_pprint_for(struct cloogoptions *options, sds dst, int indent,
		 struct clast_for *f)
{
    if (options->language == CLOOG_LANGUAGE_C) {
        if ((f->parallel & CLAST_PARALLEL_OMP) && !(f->parallel & CLAST_PARALLEL_MPI)) {
            if (f->LB) {
                dst = sdscatprintf(dst, "lbp=");
                dst = sds_pprint_expr(options, dst, f->LB);
                dst = sdscatprintf(dst, ";\n");
            }
            if (f->UB) {
                dst = sdscatprintf(dst, "%*s", indent, "");
                dst = sdscatprintf(dst, "ubp=");
                dst = sds_pprint_expr(options, dst, f->UB);
                dst = sdscatprintf(dst, ";\n");
            }
            dst = sdscatprintf(dst, "#pragma omp parallel for%s%s%s%s%s%s\n",
                    (f->private_vars)? " private(":"",
                    (f->private_vars)? f->private_vars: "",
                    (f->private_vars)? ")":"",
                    (f->reduction_vars)? " reduction(": "",
                    (f->reduction_vars)? f->reduction_vars: "",
                    (f->reduction_vars)? ")": "");
            dst = sdscatprintf(dst, "%*s", indent, "");
        }
        if ((f->parallel & CLAST_PARALLEL_VEC) && !(f->parallel & CLAST_PARALLEL_OMP)
               && !(f->parallel & CLAST_PARALLEL_MPI)) {
            if (f->LB) {
                dst = sdscatprintf(dst, "lbv=");
                dst = sds_pprint_expr(options, dst, f->LB);
                dst = sdscatprintf(dst, ";\n");
            }
            if (f->UB) {
                dst = sdscatprintf(dst, "%*s", indent, "");
                dst = sdscatprintf(dst, "ubv=");
                dst = sds_pprint_expr(options, dst, f->UB);
                dst = sdscatprintf(dst, ";\n");
            }
            dst = sdscatprintf(dst, "%*s#pragma ivdep\n", indent, "");
            dst = sdscatprintf(dst, "%*s#pragma vector always\n", indent, "");
            dst = sdscatprintf(dst, "%*s", indent, "");
        }
        if (f->parallel & CLAST_PARALLEL_MPI) {
            if (f->LB) {
                dst = sdscatprintf(dst, "_lb_dist=");
                dst = sds_pprint_expr(options, dst, f->LB);
                dst = sdscatprintf(dst, ";\n");
            }
            if (f->UB) {
                dst = sdscatprintf(dst, "%*s", indent, "");
                dst = sdscatprintf(dst, "_ub_dist=");
                dst = sds_pprint_expr(options, dst, f->UB);
                dst = sdscatprintf(dst, ";\n");
            }
            dst = sdscatprintf(dst, "%*s", indent, "");
            dst = sdscatprintf(dst, "polyrt_loop_dist(_lb_dist, _ub_dist, nprocs, my_rank, &lbp, &ubp);\n");
            if (f->parallel & CLAST_PARALLEL_OMP) {
                dst = sdscatprintf(dst, "#pragma omp parallel for%s%s%s%s%s%s\n",
                        (f->private_vars)? " private(":"",
                        (f->private_vars)? f->private_vars: "",
                        (f->private_vars)? ")":"",
                        (f->reduction_vars)? " reduction(": "",
                        (f->reduction_vars)? f->reduction_vars: "",
                        (f->reduction_vars)? ")": "");
            }
            dst = sdscatprintf(dst, "%*s", indent, "");
        }

    }

    if (options->language == CLOOG_LANGUAGE_FORTRAN)
    	dst = sdscatprintf(dst, "DO ");
    else if (options->language == CLOOG_LANGUAGE_SIGMA)
    	dst = sdscatprintf(dst, "Sum [ ");
    else
    	dst = sdscatprintf(dst, "for (");

    if (f->LB) {
      if (options->language == CLOOG_LANGUAGE_SIGMA)
        dst = sdscatprintf(dst, "%s;", f->iterator);
      else dst = sdscatprintf(dst, "%s=", f->iterator);
        if (f->parallel & (CLAST_PARALLEL_OMP | CLAST_PARALLEL_MPI)) {
            dst = sdscatprintf(dst, "lbp");
        }else if (f->parallel & CLAST_PARALLEL_VEC){
            dst = sdscatprintf(dst, "lbv");
        }else{
	          dst = sds_pprint_expr(options, dst, f->LB);
        }
    } else if (options->language == CLOOG_LANGUAGE_FORTRAN)
	    cloog_die("unbounded loops not allowed in FORTRAN.\n");

    if (options->language == CLOOG_LANGUAGE_FORTRAN)
	    dst = sdscatprintf(dst,", ");
    else
	    dst = sdscatprintf(dst,";");

    if (f->UB) {
	    if (options->language != CLOOG_LANGUAGE_FORTRAN && options->language != CLOOG_LANGUAGE_SIGMA )
	        dst = sdscatprintf(dst,"%s<=", f->iterator);
      
        if (f->parallel & (CLAST_PARALLEL_OMP | CLAST_PARALLEL_MPI)) {
            dst = sdscatprintf(dst, "ubp");
        }else if (f->parallel & CLAST_PARALLEL_VEC){
            dst = sdscatprintf(dst, "ubv");
        }else{
            dst = sds_pprint_expr(options, dst, f->UB);
        }
      if (options->language == CLOOG_LANGUAGE_SIGMA)
        dst = sdscatprintf(dst, ";");
        
    }else if (options->language == CLOOG_LANGUAGE_FORTRAN)
	    cloog_die("unbounded loops not allowed in FORTRAN.\n");

    if (options->language == CLOOG_LANGUAGE_FORTRAN) {
	    if (cloog_int_gt_si(f->stride, 1))
	        sds_cloog_int_print(dst, f->stride);
    	dst = sdscatprintf(dst,"\n");
    } else if (options->language == CLOOG_LANGUAGE_SIGMA) {
//	    fprintf(dst, ";%s=%s+", f->iterator, f->iterator);
	    sds_cloog_int_print(dst, f->stride);
	    dst = sdscatprintf(dst, " ] {\n");
   } else {
	  if (cloog_int_gt_si(f->stride, 1)) {
	      dst = sdscatprintf(dst,";%s+=", f->iterator);
	      sds_cloog_int_print(dst, f->stride);
	      dst = sdscatprintf(dst, ") {\n");
        } else
      	  dst = sdscatprintf(dst, ";%s++) {\n", f->iterator);
      }

    dst = sds_pprint_stmt_list(options, dst, indent + INDENT_STEP, f->body);

    dst = sdscatprintf(dst, "%*s", indent, "");
    if (options->language == CLOOG_LANGUAGE_FORTRAN)
    	dst = sdscatprintf(dst,"END DO\n") ; 
    else
    	dst = sdscatprintf(dst,"}\n") ; 
    
    return dst;
}

struct sll_expr * sll_clast_for(struct sll_expr * context, struct cloogoptions *options, struct clast_for *f)
{
	struct sll_for * sf = new_sll_for(context);

	sf->iterator = sdsnew(f->iterator);
    if (f->LB) {
    	sf->lb = sds_pprint_expr(options, sdsnew(""), f->LB);
    }
    if (f->UB) {
        sf->ub = sds_pprint_expr(options, sdsnew(""), f->UB);
    }
    sds_cloog_int_print(sf->stride, f->stride);

    sf->body = sll_clast_stmt_list(&(sf->expr), options, f->body);

    return &(sf->expr);
}

sds sds_sll_for(sds dst, int indent, struct sll_for *sf)
{
	sds hash = sdsnew("#");

	if(sdscmp(sf->expr.out, hash) == 0)
		dst = sdscatprintf(dst, "For [ ");
	else
		dst = sdscatprintf(dst, "Sum [ ");
	dst = sdscatprintf(dst, "%s;", sf->iterator);
	dst = sdscatprintf(dst, "%s;", sf->lb);
	dst = sdscatprintf(dst, "%s;", sf->ub);
	dst = sdscatprintf(dst, "%s ] {\n", sf->stride);

    dst = sds_sll_stmt(dst, indent + INDENT_STEP, (struct sll_stmt *)(sf->body));

    dst = sdscatprintf(dst, "%*s}\n", indent, "");

    sdsfree(hash);

    return dst;
}

void pprint_stmt_list(struct cloogoptions *options, FILE *dst, int indent,
		       struct clast_stmt *s)
{
  for ( ; s; s = s->next) {
	  if (CLAST_STMT_IS_A(s, stmt_root)) {
	      continue;
	  }
	  fprintf(dst, "%*s", indent, "");
	  if (CLAST_STMT_IS_A(s, stmt_ass)) {
	      pprint_assignment(options, dst, (struct clast_assignment *) s);
	      if (options->language != CLOOG_LANGUAGE_FORTRAN)
      		fprintf(dst, ";");
	      fprintf(dst, "\n");
	  } else if (CLAST_STMT_IS_A(s, stmt_user)) {
  	      pprint_user_stmt(options, dst, (struct clast_user_stmt *) s);
	  } else if (CLAST_STMT_IS_A(s, stmt_for)) {
	      pprint_for(options, dst, indent, (struct clast_for *) s);
	  } else if (CLAST_STMT_IS_A(s, stmt_guard)) {
	      pprint_guard(options, dst, indent, (struct clast_guard *) s);
	  } else if (CLAST_STMT_IS_A(s, stmt_block)) {
	      fprintf(dst, "{\n");
	      pprint_stmt_list(options, dst, indent + INDENT_STEP, 
				  ((struct clast_block *)s)->body);
	      fprintf(dst, "%*s", indent, "");
	      fprintf(dst, "}\n");
	  } else {
	      assert(0);
	  }
    if (options->language == CLOOG_LANGUAGE_SIGMA) {
      if(s->next) {
	      fprintf(dst, "%*s", indent, "");
	      fprintf(dst, "+\n");
	    }
    }
	
  }
}

sds sds_pprint_stmt_list(struct cloogoptions *options, sds dst, int indent,
		       struct clast_stmt *s)
{
  for ( ; s; s = s->next) {
	  if (CLAST_STMT_IS_A(s, stmt_root)) {
	      continue;
	  }
	  dst = sdscatprintf(dst, "%*s", indent, "");
	  if (CLAST_STMT_IS_A(s, stmt_ass)) {
	      dst = sds_pprint_assignment(options, dst, (struct clast_assignment *) s);
	      if (options->language != CLOOG_LANGUAGE_FORTRAN)
      		dst = sdscatprintf(dst, ";");
	      dst = sdscatprintf(dst, "\n");
	  } else if (CLAST_STMT_IS_A(s, stmt_user)) {
  	      dst = sds_pprint_user_stmt(options, dst, (struct clast_user_stmt *) s);
	  } else if (CLAST_STMT_IS_A(s, stmt_for)) {
	      dst = sds_pprint_for(options, dst, indent, (struct clast_for *) s);
	  } else if (CLAST_STMT_IS_A(s, stmt_guard)) {
	      dst = sds_pprint_guard(options, dst, indent, (struct clast_guard *) s);
	  } else if (CLAST_STMT_IS_A(s, stmt_block)) {
	      dst = sdscatprintf(dst, "{\n");
	      dst = sds_pprint_stmt_list(options, dst, indent + INDENT_STEP, 
				  ((struct clast_block *)s)->body);
	      dst = sdscatprintf(dst, "%*s", indent, "");
	      dst = sdscatprintf(dst, "}\n");
	  } else {
	      assert(0);
	  }
    if (options->language == CLOOG_LANGUAGE_SIGMA) {
      if(s->next) {
	      dst = sdscatprintf(dst, "%*s", indent, "");
	      dst = sdscatprintf(dst, "+\n");
	    }
    }
	
  }
  
  return dst;
}

struct sll_expr * sll_clast_stmt_list(struct sll_expr *context, struct cloogoptions *options, struct clast_stmt *s)
{
	struct sll_entry * se = new_sll_entry(context);
	struct sll_expr * e = &(se->expr);

	for ( ; s; s = s->next) {
		if (CLAST_STMT_IS_A(s, stmt_root)) {
			continue;
		}
		if (CLAST_STMT_IS_A(s, stmt_user)) {
			e->next = sll_clast_user_stmt(context, options, (struct clast_user_stmt *) s);
		} else if (CLAST_STMT_IS_A(s, stmt_for)) {
			e->next = sll_clast_for(context, options, (struct clast_for *) s);
		} else if (CLAST_STMT_IS_A(s, stmt_guard)) {
			e->next = sll_clast_guard(context, options, (struct clast_guard *) s);
		} else if (CLAST_STMT_IS_A(s, stmt_block)) {
			struct sll_block * sb = new_sll_block(context);
			sb->body = sll_clast_stmt_list(&(sb->expr), options, ((struct clast_block *)s)->body);
			e->next = &(sb->expr);
		} else {
			assert(0);
		}
		e = e->next;
		se->len++;
	}

	return &(se->expr);
}

sds sds_sll_expr_list(sds dst, int indent, struct sll_expr *s)
{
	int i;
	struct sll_entry * se = (struct sll_entry *)s;
	sds hash = sdsnew("#");

	if ((sdscmp(s->out, hash) != 0) && ((s->context == NULL) || (sdscmp(s->context->out, hash) == 0))) {
		dst = sdscatprintf(dst, "%*s", indent, "");
		dst = sdscatprintf(dst, "%s = ", s->out);
	}

	for (i = 0; i < se->len; i++) {
		s = s->next;
		dst = sdscatprintf(dst, "%*s", indent, "");
		if (SLL_EXPR_IS_A(s, sll_et_inner)) {
			dst = sds_sll_inner_expr(dst, (struct sll_inner_expr *) s);
		} else if (SLL_EXPR_IS_A(s, sll_et_for)) {
			dst = sds_sll_for(dst, indent, (struct sll_for *) s);
		} else if (SLL_EXPR_IS_A(s, sll_et_guard)) {
			dst = sds_sll_guard(dst, indent, (struct sll_guard *) s);
		} else if (SLL_EXPR_IS_A(s, sll_et_block)) {
			dst = sdscatprintf(dst, "{\n");
			dst = sds_sll_expr_list(dst, indent + INDENT_STEP, ((struct sll_block *)s)->body);
			dst = sdscatprintf(dst, "%*s}\n", indent, "");
		} else {
			assert(0);
		}
		if(s->next) {
			dst = sdscatprintf(dst, "%*s+\n", indent, "");
		}
	}

//	if ((sdscmp(s->out, "#") != 0) && (s->context == NULL)) {
	if ((s->context == NULL) || (sdscmp(s->context->out, hash) == 0)) {
		dst = sdscatprintf(dst, "%*s;\n", indent, "");
	}

	sdsfree(hash);

	return dst;

}

sds sds_sll_stmt(sds dst, int indent, struct sll_stmt *ss)
{
	struct sll_expr* curr_stmt = &(ss->expr);
	for (; curr_stmt != NULL; curr_stmt = curr_stmt->next) {
			dst = sds_sll_expr_list(dst, indent, ((struct sll_stmt *)curr_stmt)->body);
	}

    return dst;
}


/******************************************************************************
 *                       Pretty Printing (dirty) functions                    *
 ******************************************************************************/

void clast_pprint(FILE *foo, struct clast_stmt *root,
		  int indent, CloogOptions *options)
{
    pprint_stmt_list(options, foo, indent, root);
}

sds sds_clast_pprint(char const* s, struct clast_stmt *root, int indent, CloogOptions *options)
{
    return sds_pprint_stmt_list(options, sdsnew(s), indent, root);
}

sds sll_pprint(char const* s, struct clast_stmt *root, int indent, CloogOptions *options)
{
    struct sll_expr * e = sll_clast_stmt_list(NULL, options, root);
    struct sll_expr * p = build_sll_program(e);
//    sds dst = sds_sll_expr_list(sdsnew(s), indent, e);
    sds dst = sds_sll_stmt(sdsnew(s), indent, (struct sll_stmt *)p);
    sll_free(p);

    return dst;
}
