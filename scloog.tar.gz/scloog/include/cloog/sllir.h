/*
 * sllir.h
 *
 *  Created on: Jun 25, 2015
 *      Author: danieles
 */

#ifndef SLLIR_H_
#define SLLIR_H_

#include "../include/cloog/sds.h"

struct sll_expr;

struct sll_etype {
    void (*free)(struct sll_expr *);
};

#define SLL_EXPR_IS_A(expr, type) ((expr)->et == &(type))

extern const struct sll_etype sll_et_entry;
extern const struct sll_etype sll_et_stmt;
extern const struct sll_etype sll_et_inner;
extern const struct sll_etype sll_et_block;
extern const struct sll_etype sll_et_for;
extern const struct sll_etype sll_et_guard;

struct sll_expr {
    const struct sll_etype *et;
    struct sll_expr	*context;
    struct sll_expr	*next;
    int eq_id;
    sds out, scat;
};

struct sll_stmt {
    struct sll_expr	expr;
    struct sll_expr *body;
};

struct sll_entry {
    struct sll_expr	expr;
    int len;
};

struct sll_block {
    struct sll_expr	expr;
    struct sll_expr *body;
};

struct sll_inner_expr {
    struct sll_expr	expr;
    sds text;
};

struct sll_for {
    struct sll_expr	expr;
    struct sll_expr * body;
    sds iterator, lb, ub, stride;
};

struct sll_guard {
    struct sll_expr	expr;
    struct sll_expr * then;
    sds cond;
};


struct sll_entry *new_sll_entry(struct sll_expr * context);
struct sll_inner_expr *new_sll_inner_expr(struct sll_expr * context);
struct sll_block *new_sll_block(struct sll_expr * context);
struct sll_for *new_sll_for(struct sll_expr * context);
struct sll_guard *new_sll_guard(struct sll_expr * context);

void free_sll_expr(struct sll_expr *s);
void sll_free(struct sll_expr *s);

#endif /* SLLIR_H_ */
