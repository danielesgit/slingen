/* Generated from ../../../git/cloog/test/param-split.cloog by CLooG 0.14.0-277-gce2ba57 gmp bits in 0.00s. */
for (i=0;i<=M;i++) {
  S1(i);
  if (i == 0) {
    S2(i);
  }
}
if (M <= -1) {
  S2(0);
}
