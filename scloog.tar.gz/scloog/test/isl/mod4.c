/* Generated from ../../../git/cloog/test/isl/mod4.cloog by CLooG 0.16.0-9-g188dbd4 gmp bits in 0.00s. */
if (M%11 <= 6) {
  if (N%5 <= 2) {
    if (M >= -N) {
      for (i=0;i<=M+N;i++) {
        S1(i);
      }
    }
  }
}
