/* Generated from ../../../git/cloog/test/guide.cloog by CLooG 0.14.0-245-gd8c1718 gmp bits in 0.00s. */
if (N >= 1) {
  for (i=1;i<=N;i++) {
    S1(i);
  }
  for (i=N+1;i<=2*N;i++) {
    S2(i);
  }
}
