/* Generated from ../../../git/cloog/test/rectangle.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.00s. */
for (c1=0;c1<=2*n;c1++) {
  for (i=max(0,c1-n);i<=min(c1,n);i++) {
    S1(i,c1-i) ;
  }
}
