/* Generated from ../../../git/cloog/test/uday_scalars.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.01s. */
if (n >= 0) {
  for (p3=0;p3<=n;p3++) {
    S1(p3,0,0) ;
  }
  for (p3=0;p3<=n;p3++) {
    S2(0,p3,0) ;
  }
}
