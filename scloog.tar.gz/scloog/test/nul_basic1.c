/* Generated from ../../../git/cloog/test/nul_basic1.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.00s. */
if (M >= 0) {
  for (i=0;i<=M;i+=2) {
    S1(i,i/2) ;
  }
}
