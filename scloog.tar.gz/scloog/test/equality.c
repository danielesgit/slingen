/* Generated from ../../../git/cloog/test/equality.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.01s. */
for (i0=0;i0<=5;i0++) {
  for (i1=ceild(4*i0,5);i1<=floord(6*i0+20,5);i1++) {
    if (2*i0 == i1) {
      S1(i0,i1) ;
    }
    if (i1 == 4) {
      S2(i0,i1) ;
    }
  }
}
